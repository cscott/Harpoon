
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */




/** 
 * Name: abstime.c 
 * This program is the native method implementation for 
 * class javax.realtime.AbsoluteTime.java
 * private native void nativeSetTime(long millis, int nanos);
 * private native int getSystemCurNanos();
 * private native long getSystemCurMillis();
 */

#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <jni.h>


JNIEXPORT void JNICALL Java_javax_realtime_AbsoluteTime_nativeSetTime(JNIEnv *p_env, 
                                                                      jclass p_class, 
                                                                      jlong millis, 
                                                                      jlong nanos)
{
    struct timespec tm;

    p_env;
    p_class;

    tm.tv_sec = millis/1000;
    tm.tv_nsec = nanos + (millis- tm.tv_sec *1000)*1000000; 
    if(clock_settime(CLOCK_REALTIME, &tm) ==-1)
       perror("Clock set time");

}

JNIEXPORT jint JNICALL Java_javax_realtime_AbsoluteTime_getSystemCurNanos(JNIEnv *p_env, 
                                                                          jclass p_class)
{
    struct timespec tp;
    jint nanos= -1;
    jlong tn;
    jboolean isError;

    isError = JNI_FALSE;
    if(clock_gettime(CLOCK_REALTIME,&tp) == -1)
    {
        perror("clock get time");
        isError = JNI_TRUE;
    }
    if(!isError)
    {
      tn=tp.tv_nsec;
    
      while(tn >=1000000)
        tn = tn-1000000;
      nanos=tn;
    }
    
    return nanos;
}


JNIEXPORT jlong JNICALL Java_javax_realtime_AbsoluteTime_getSystemCurMillis(JNIEnv *p_env, 
                                                                            jclass p_class)
{
    struct timespec tp;
    jlong millis= -1;
    jlong nanos;
    int tm;

    jboolean isError;

    isError = JNI_FALSE;
    if(clock_gettime(CLOCK_REALTIME,&tp) == -1)
    {
        perror("clock get time");
        isError = JNI_TRUE;
    }
    if(!isError)
    {
      millis=tp.tv_sec*1000;
      nanos=tp.tv_nsec;
      if(nanos > 1000000)
      {
         tm=nanos/1000000;
         millis+=tm;
         nanos=nanos-tm*1000000;
      }

    }

    return millis;
}



/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include<jni.h>
#include"j9comp.h"

void checkStore(jobject, jobject);

int addMemoryArea(void *, void *, void *);

int removeMemoryArea(void *, void *, void *);

void startChecking();

void stopChecking();

void illegalStore();

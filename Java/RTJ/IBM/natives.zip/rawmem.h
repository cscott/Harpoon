
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */



#include <jni.h>
/* Header for class javax_realtime_RawMemoryAccess */

#ifndef _RAWMEM
#define _RAWMEM
#ifdef __cplusplus
extern "C" {
#endif
/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeGetByte
 * Signature: (JJ)B
 */
JNIEXPORT jbyte JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetByte(JNIEnv *, 
                                                                          jobject, 
                                                                          jlong, 
                                                                          jlong);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeGetBytes
 * Signature: (JJ[BII)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetBytes(JNIEnv *, 
                                                                          jobject, 
                                                                          jlong, 
                                                                          jlong, 
                                                                          jbyteArray, 
                                                                          jint, 
                                                                          jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeGetInt
 * Signature: (JJ)B
 */
JNIEXPORT jint JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetInt(JNIEnv *, 
                                                                        jobject, 
                                                                        jlong, 
                                                                        jlong);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeGetInts
 * Signature: (JJ[III)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetInts(JNIEnv *, 
                                                                         jobject, 
                                                                         jlong, 
                                                                         jlong, 
                                                                         jintArray, 
                                                                         jint, 
                                                                         jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeGetLong
 * Signature: (JJ)J
 */
JNIEXPORT jlong JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetLong(JNIEnv *, 
                                                                          jobject, 
                                                                          jlong, 
                                                                          jlong);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeGetLongs
 * Signature: (JJ[JII)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetLongs(JNIEnv *, 
                                                                          jobject, 
                                                                          jlong, 
                                                                          jlong, 
                                                                          jlongArray, 
                                                                          jint, 
                                                                          jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeGetShort
 * Signature: (JJ)S
 */
JNIEXPORT jshort JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetShort(JNIEnv *, 
                                                                            jobject, 
                                                                            jlong, 
                                                                            jlong);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeGetShorts
 * Signature: (JJ[SII)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetShorts(JNIEnv *, 
                                                                           jobject, 
                                                                           jlong, 
                                                                           jlong, 
                                                                           jshortArray, 
                                                                           jint, 
                                                                           jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeSetByte
 * Signature: (JJB)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetByte(JNIEnv *, 
                                                                         jobject, 
                                                                         jlong, 
                                                                         jlong, 
                                                                         jbyte);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeSetBytes
 * Signature: (JJ[BII)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetBytes(JNIEnv *, 
                                                                          jobject, 
                                                                          jlong, 
                                                                          jlong, 
                                                                          jbyteArray, 
                                                                          jint, 
                                                                          jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeSetInt
 * Signature: (JJI)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetInt(JNIEnv *, 
                                                                        jobject, 
                                                                        jlong, 
                                                                        jlong, 
                                                                        jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeSetInts
 * Signature: (JJ[III)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetInts(JNIEnv *, 
                                                                         jobject, 
                                                                         jlong, 
                                                                         jlong, 
                                                                         jintArray, 
                                                                         jint, 
                                                                         jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeSetLong
 * Signature: (JJJ)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetLong(JNIEnv *, 
                                                                         jobject, 
                                                                         jlong, 
                                                                         jlong, 
                                                                         jlong);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeSetLongs
 * Signature: (JJ[JII)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetLongs(JNIEnv *, 
                                                                          jobject, 
                                                                          jlong, 
                                                                          jlong, 
                                                                          jlongArray, 
                                                                          jint, 
                                                                          jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeSetShort
 * Signature: (JJS)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetShort(JNIEnv *, 
                                                                          jobject, 
                                                                          jlong, 
                                                                          jlong, 
                                                                          jshort);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeSetShorts
 * Signature: (JJ[SII)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetShorts(JNIEnv *, 
                                                                           jobject, 
                                                                           jlong, 
                                                                           jlong, 
                                                                           jshortArray, 
                                                                           jint, 
                                                                           jint);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeMap
 * Signature: (JJ)J
 */
JNIEXPORT jlong JNICALL Java_javax_realtime_RawMemoryAccess_nativeMap(JNIEnv *, 
                                                                      jobject, 
                                                                      jlong, 
                                                                      jlong);

/*
 * Class:     javax_realtime_RawMemoryAccess
 * Method:    nativeUnmap
 * Signature: (JJ)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeUnmap(JNIEnv *, 
                                                                       jobject, 
                                                                       jlong, 
                                                                       jlong);

#ifdef __cplusplus
}
#endif
#endif

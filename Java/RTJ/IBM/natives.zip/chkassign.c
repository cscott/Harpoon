
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */



/** 
 * Name: chkassign.c 
 * The following methods provide memory checking for real time extensions.
 * The extensions defines memory areas such as Immortal, Scoped, Heap, and
 * Local Variable.  With these memory areas are rules reference and access
 * rules, which this code supports.  
 *
 *          Reference       Reference       Reference
 *              to              to              to
 *          Heap            Immortal        Scoped
 * ------------------------------------------------------
 * Heap     |   Yes         |   Yes         |   No
 * ------------------------------------------------------
 * Immortal |   Yes         |   Yes         |   No
 * ------------------------------------------------------
 * Scoped   |   Yes         |   Yes         |   Yes, if same, outer, or shared scope
 * ------------------------------------------------------
 * Local    |   Yes         |   Yes         |   Yes, if same, outer, or shared scope
 * Variable
 * ------------------------------------------------------
 */


#include "chkassign.h"

#define HASHPRIME 31

//#define DEBUG_FUNCTIONS

//#define DEBUG(x) printf x
#define DEBUG(x)

//#define DEBUG_VERBOSE(x) printf x
#define DEBUG_VERBOSE(x)

//#define ASSERT(x,y) if(!(x)) printf("<ASSERT FAILED: %s>\n", y)
#define ASSERT(x, string)

typedef struct AreaRangeTree 
{
    void * startAddress;
    void * endAddress;
    void * outerScopeAddress;
    struct AreaRangeTree * leftChild;
    struct AreaRangeTree * rightChild;
} MemoryAreaRangeTree, * MemoryAreaRangeTreePtr;

typedef struct AddressToTreeListNode 
{
    void * address;
    MemoryAreaRangeTreePtr tree;
    struct AddressToTreeListNode * next;
} AddressToTree, * AddressToTreePtr, ** AddressToTreeHashTable;

/* A binary tree with NULL pointers for external nodes and
 * MemoryAreaRangeTree for internal nodes. */
MemoryAreaRangeTreePtr memoryAreaRangeTreePtr = NULL;

/* An array representing a hash table */
AddressToTreeHashTable addressToTreeHashTable = NULL;

int numberOfEntries = 0;

int shouldCheck = TRUE;


void removeAddressNode (MemoryAreaRangeTreePtr, void *, int);
void removeLeftChildNode (MemoryAreaRangeTreePtr, int);
void removeRightChildNode (MemoryAreaRangeTreePtr, int);
void transferNode (MemoryAreaRangeTreePtr, MemoryAreaRangeTreePtr);

void startChecking() 
{
    shouldCheck = TRUE;
}

void stopChecking() 
{
    shouldCheck = FALSE;
}

void checkStore(jobject dest, jobject source) 
{
    // DEBUG (("\n<checkstore dest: %d, source %d, shouldCheck %d, numEntries: %d>\n", dest, source, shouldCheck, numberOfEntries));
    /* If we aren't checking, simply return true */
    /* Also do a quick check to see if we are storing null (!source)--this is always allowed */
    /* Also if there are no scoped memory areas then all assignments are allowed */
    if (!shouldCheck || !source || numberOfEntries == 0) {
        DEBUG_VERBOSE(("\n<checkstore dest: %d, source: %d simple case>\n", dest, source));
        return;
    } else {
        /* If only they were all that easy... */
        MemoryAreaRangeTreePtr sourceTree;
        MemoryAreaRangeTreePtr destTree;
        DEBUG(("\n<checkstore dest: %d, source: %d complicated case>\n", dest, source));
        /* Now check to see if the source */
        /* is inside a scoped memory */
        sourceTree = (MemoryAreaRangeTreePtr) searchTreeFor((void *)source);        
        if (sourceTree == NULL) {
            DEBUG (("\n<sourceTree = %d>\n", sourceTree));
        } else {
            DEBUG (("\n<sourceTree = %d, tree->outerScopeAddress = %d>\n", sourceTree, sourceTree->outerScopeAddress));            
        }

        if (sourceTree == NULL || sourceTree->outerScopeAddress == 0) {
            /* The source is not in a scoped memory--therefore, we can store it. */
            DEBUG (("<The source is not in a scoped memory--therefore, we can store it>\n"));
            return;            
        } else {
            /* Check to see if the dest is a scoped memory */
            destTree = (MemoryAreaRangeTreePtr) searchTreeFor((void *)dest);
            if (destTree == NULL) {
                // should this ever happen?  should this store be allowed?
                // illegalStore(dest, source);
                return;
            } else if (destTree->outerScopeAddress == 0) {
                /* The destination isn't a scoped memory, so this store is not allowed */
                DEBUG (("<The destination isn't a scoped memory, so this store is not allowed>\n"));
                DEBUG (("<destTree: %d, destTreeStartAddress: %d, sourceTree: %d, sourceTreeStartAddress: %d>\n", destTree, destTree->startAddress, sourceTree, sourceTree->startAddress));
                DEBUG (("<checkstore dest: %d, source %d, shouldCheck %d, numEntries: %d>\n", dest, source, shouldCheck, numberOfEntries));
                illegalStore(dest, source);
                return;
            } else {
                /* The most complicated case...                           */
                /* We know that source and dest are both scoped memories, */
                /* so allow the store iff source and dest are in the same */
                /* memory area, or if source is in a parent memory (outer */
                /* scope) area of dest.                                   */
                if (sourceTree == destTree) {
                    return;
                } else {
                    void * nextParent = destTree->outerScopeAddress;
                    while (nextParent != NULL) {
                        AddressToTreePtr node;
                        if (nextParent == sourceTree) {
                            return;
                        }
                        node = addressToTreeHashTable[(int)nextParent % HASHPRIME];
                        while (node != NULL && node->address != nextParent) {
                            node = node->next;
                        }
                        if (node == NULL) {
                            nextParent = NULL;
                        } else {
                            nextParent = node->tree->outerScopeAddress;
                        }
                    }
                    DEBUG (("\n<Both source and dest are scoped memories, but dest is not a child of or equal to source>\n"));
                    DEBUG (("<destTree: %d, destTreeStartAddress: %d, sourceTree: %d, sourceTreeStartAddress: %d>\n", destTree, destTree->startAddress, sourceTree, sourceTree->startAddress));
                    DEBUG (("<checkstore dest: %d, source %d, shouldCheck %d, numEntries: %d>\n", dest, source, shouldCheck, numberOfEntries));
                    illegalStore(dest, source);
                    return;
                }                
            }
        }
    }
}


int addMemoryArea(void * startAddress, void * endAddress, void * outerScopeAddress) 
{
    MemoryAreaRangeTreePtr memoryAreaNode;
    DEBUG(("<addMemoryArea called with %d %d %d>\n", startAddress, endAddress, outerScopeAddress));

    { /* Add node to tree */
        MemoryAreaRangeTreePtr * temp;
        if (numberOfEntries == 0) {
            int i;
            addressToTreeHashTable = (AddressToTreeHashTable) malloc(sizeof(AddressToTree) * HASHPRIME);
            for (i = 0; i < HASHPRIME; i++) {
                addressToTreeHashTable[i] = NULL;
            }
        }
    
        memoryAreaNode = (MemoryAreaRangeTreePtr) malloc(sizeof(MemoryAreaRangeTree));
        memoryAreaNode->startAddress = startAddress;
        memoryAreaNode->endAddress = endAddress;
        memoryAreaNode->outerScopeAddress = outerScopeAddress;
        memoryAreaNode->leftChild = NULL;
        memoryAreaNode->rightChild = NULL;
    
        temp = &memoryAreaRangeTreePtr;
        while (*temp != NULL) {
            if ((*temp)->startAddress > memoryAreaNode->endAddress) {
                temp = &((*temp)->leftChild);
            } else {
                temp = &((*temp)->rightChild);
            }
        }
        *temp = memoryAreaNode;
        DEBUG(("<Added to tree OK at: %d>\n", *temp));
    }
    
    { /* Add mapping from address to tree for faster lookup */
        AddressToTreePtr addressToTreeNode;
        AddressToTreePtr * temp;
    
        addressToTreeNode = (AddressToTreePtr) malloc(sizeof(AddressToTree));
    
        addressToTreeNode->address = startAddress;
        addressToTreeNode->tree = memoryAreaNode;
        addressToTreeNode->next = NULL;

        temp = &(addressToTreeHashTable[(int)startAddress % HASHPRIME]);
        while (*temp != NULL) {
            temp = &((*temp)->next);
        }
        *temp = addressToTreeNode;
   }

   numberOfEntries++;

   DEBUG(("<addMemoryArea returning...  numberOfEntires = %d>\n", numberOfEntries));

   return 0;
};


int removeMemoryArea(void * startAddress, void * endAddress, void * outerScopeAddress) 
{
    int hashResult;
    
    DEBUG(("<removeMemoryArea called with %d %d %d>\n", startAddress, endAddress, outerScopeAddress));

    {/* Remove the node from the hash table */
        AddressToTreePtr * temp;
        AddressToTreePtr temp2;
        hashResult = (int)startAddress % HASHPRIME;
        temp = &(addressToTreeHashTable[hashResult]);
        while ((*temp)->address != startAddress) {
            temp = &((*temp)->next);
            ASSERT (temp, "Remove in hash came accross null element");
        }
        temp2 = (*temp);
        (*temp) = (*temp)->next;
        free(temp2);
    }

    DEBUG (("<Root startAddress: %d, node startAddress: %d>\n", memoryAreaRangeTreePtr->startAddress, startAddress));

    /* Now remove the node from the tree */
    if (memoryAreaRangeTreePtr->leftChild == NULL && memoryAreaRangeTreePtr->rightChild == NULL) {
        /* We are removing the only node */
        ASSERT(numberOfEntries == 1, "Tree has only one node but numberOfEntries != 1");
        DEBUG (("<Removing ONLY node>\n"));
        free (memoryAreaRangeTreePtr);
        memoryAreaRangeTreePtr = NULL;
    } else if ((memoryAreaRangeTreePtr->startAddress) == startAddress) {
        /* We are removing the top node. */
        MemoryAreaRangeTreePtr temp;
        DEBUG (("<Removing ROOT node>\n"));
        temp = memoryAreaRangeTreePtr;
        if (memoryAreaRangeTreePtr->leftChild == NULL) {
            memoryAreaRangeTreePtr = memoryAreaRangeTreePtr->rightChild;
            free(temp);
        } else if (memoryAreaRangeTreePtr->rightChild == NULL) {
            memoryAreaRangeTreePtr = memoryAreaRangeTreePtr->leftChild;
            free(temp);            
        } else {
            if (hashResult % 2) {
                DEBUG (("<Called removeLeftChildNode>\n"));
                transferNode(memoryAreaRangeTreePtr, memoryAreaRangeTreePtr->leftChild);
                removeLeftChildNode(memoryAreaRangeTreePtr, 0);
            } else {
                DEBUG (("<Called removeRightChildNode>\n"));
                transferNode(memoryAreaRangeTreePtr, memoryAreaRangeTreePtr->rightChild);
                removeRightChildNode(memoryAreaRangeTreePtr, 1);
            }
        }
    } else {
        removeAddressNode(memoryAreaRangeTreePtr, startAddress, hashResult % 2);
    }

    numberOfEntries--;

    DEBUG(("<removeMemoryArea returning...  numberOfEntires = %d>\n", numberOfEntries));

    return 0;
};


void illegalStore(jobject dest, jobject source) 
{
    JavaVM * javaVMs;
    jsize numVMs;
    stopChecking();
    DEBUG (("<Getting VMs>\n"));
    JNI_GetCreatedJavaVMs(&javaVMs, 1, &numVMs);
    DEBUG (("<Got VMs.  Number of VMs: %d>\n", numVMs));
    if (numVMs > 1) {
        // Don't know how to handle this case any better...
        // But we shouldn't have multiple VMs running in
        // the same process anyway.
        printf("<* Illegal store.  destination: %d, source: %d *>\n", dest, source);
    } else {
        
        JavaVM * vm = javaVMs;
        JNIEnv * env = 0;
        jclass memoryAccessErrorClass;
        jthrowable ex;
        int result;
        DEBUG (("<* Illegal store.  destination: %d, source: %d *>\n", dest, source));
        result = GetEnv(vm, &env, JNI_VERSION_1_2);
        DEBUG (("<Result of GetEnv: %d, env = %d>\n", result, (int)env));

        // Right now the exception-throwing code below isn't working so I'm doing a Fatal Error instead
        (*env)->FatalError(env, "Illegal Memory Assignment");
        /*
        DEBUG (("<Getting throwable object>\n"));
        memoryAccessErrorClass = (*env)->FindClass(env, "javax/realtime/MemoryAccessError");
        if (ex = (*env)->ExceptionOccurred(env)) {
            printf("<Exception Occured>");
            (*env)->ExceptionDescribe(env);
        }
        //memoryAccessErrorClass = (*env)->FindClass(env, "java/lang/Throwable");
        //memoryAccessErrorClass = (*env)->FindClass(env, "java/lang/Error");
        DEBUG (("<FindClass returned: %d>\n", memoryAccessErrorClass));
        if (ex = (*env)->ExceptionOccurred(env)) {
            DEBUG (("<Exception Occured>"));
            (*env)->ExceptionDescribe(env);
        }
        DEBUG (("<Throwing throwable>\n"));
        (*env)->ThrowNew(env, memoryAccessErrorClass, "Illegal Memory Assignment"); 
        */
    }
    startChecking();
}


searchTreeFor(void * address) 
{
    MemoryAreaRangeTreePtr nextTree = memoryAreaRangeTreePtr;
    while (nextTree != NULL) {
        if (address < nextTree->startAddress) {
            nextTree = nextTree->leftChild;
        } else if (address > nextTree->endAddress) {
            nextTree = nextTree->rightChild;
        } else {
            return (int) nextTree;
        }
    }
    return NULL;
}


void removeAddressNode (MemoryAreaRangeTreePtr tree, void * address, int coinFlip) 
{
    MemoryAreaRangeTreePtr temp;
    DEBUG (("<called removeAddressNode(%d, %d, %d)>\n", tree, address, coinFlip));
    if (address < tree->startAddress) {
        if (tree->leftChild->startAddress == address) {
            /* remove the left child */
            removeLeftChildNode(tree, coinFlip);
        } else {
            removeAddressNode(tree->leftChild, address, coinFlip);
        }
    } else {
        if (tree->rightChild->startAddress == address) {
            /* remove the right child */
            removeRightChildNode(tree, coinFlip);
        } else {
            removeAddressNode(tree->rightChild, address, coinFlip);
        }
    }
}

void removeChildNode (MemoryAreaRangeTreePtr parent, MemoryAreaRangeTreePtr child, int coinFlip) 
{
    MemoryAreaRangeTreePtr temp;
    DEBUG(("<called removeChildNode(%d, %d, %d)>\n", parent, child, coinFlip));
    if (child->leftChild == NULL) {
        temp = child->rightChild;
        transferNode(child, temp);
        child->leftChild = temp->leftChild;
        child->rightChild = temp->rightChild;
        free(temp);
    } else if (child->rightChild == NULL) {
        temp = child->leftChild;
        transferNode(child, temp);
        child->leftChild = temp->leftChild;
        child->rightChild = temp->rightChild;
        free(temp);
    } else {
        removeRandomChildNode(child, coinFlip);
    }
}


void removeLeftChildNode (MemoryAreaRangeTreePtr parent, int coinFlip) 
{
    if (parent->leftChild->leftChild == NULL && parent->leftChild->rightChild == NULL) {
        free(parent->leftChild);
        parent->leftChild = NULL;
    } else {
        removeChildNode(parent, parent->leftChild, coinFlip);
    }
}


void removeRightChildNode (MemoryAreaRangeTreePtr parent, int coinFlip) 
{
    if (parent->rightChild->leftChild == NULL && parent->rightChild->rightChild == NULL) {
        free(parent->rightChild);
        parent->rightChild = NULL;
    } else {
        removeChildNode(parent, parent->rightChild, coinFlip);
    }
}


void transferNode (MemoryAreaRangeTreePtr dest, MemoryAreaRangeTreePtr source) 
{
    dest->startAddress = source->startAddress;
    dest->endAddress = source->endAddress;
    dest->outerScopeAddress = source->outerScopeAddress;
}


removeRandomChildNode (MemoryAreaRangeTreePtr node, int coinFlip) 
{
    if (coinFlip) {
        transferNode(node, node->leftChild);
        removeLeftChildNode(node->leftChild, !coinFlip);
    } else {
        transferNode(node, node->rightChild);
        removeRightChildNode(node->rightChild, !coinFlip);
    }
}


#ifdef DEBUG_FUNCTIONS
void printTree() 
{
    printf("--Tree--\n");
    subPrintTree(memoryAreaRangeTreePtr, 0);
}

void subPrintTree(MemoryAreaRangeTreePtr root, int tab) 
{
    if (root == NULL) {
        printTab(tab);
        printf ("NULL\n");
    } else {
        printTab(tab);
        printf ("Node At: %d\n", root);
        printTab(tab);
        printf ("StartAddress: %d\n", root->startAddress);
        printTab(tab);
        printf ("EndAddress: %d\n", root->endAddress);
        printTab(tab);
        printf ("OuterAddress: %d\n", root->outerScopeAddress);
        printTab(tab);
        printf ("LeftChild:\n");
        subPrintTree(root->leftChild, tab + 4);
        printTab(tab);
        printf ("RightChild:\n");
        subPrintTree(root->rightChild, tab + 4);
    }

}

void printTab (int num) 
{
    int i;
    for (i = 0; i < num; i++) {
        printf(" ");
    }
}
#endif
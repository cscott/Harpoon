
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include "memarea.h"
#include "chkassign.h"

JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_addToNativeSpaceTableImpl(JNIEnv * env, 
                                                                                jobject jobj, 
                                                                                jlong address, 
                                                                                jlong size, 
                                                                                jlong outerAddress) 
{
    addMemoryArea((void *)address, (void *)(address + size), (void *)outerAddress);
}

JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_removeFromNativeSpaceTableImpl(JNIEnv * env, 
                                                                                     jobject jobj, 
                                                                                     jlong address, 
                                                                                     jlong size, 
                                                                                     jlong outerAddress) 
{
    removeMemoryArea((void *)address, (void *)(address + size), (void *)outerAddress);
}


JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_startMemoryChecking(JNIEnv * env, 
                                                                          jclass cls) 
{
    startChecking();
}

JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_stopMemoryChecking(JNIEnv * env, 
                                                                         jclass cls) 
{
    stopChecking();
}

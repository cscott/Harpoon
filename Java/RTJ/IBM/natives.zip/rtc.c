
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include <time.h>
#include <jni.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/neutrino.h>


void Java_javax_realtime_RealtimeClock_setRealtimeClock(JNIEnv *p_env, jclass p_class,
                                                                jlong millis, jlong nanos)
{

    struct timespec tm;
  
    tm.tv_sec = millis/1000;
    tm.tv_nsec = nanos + (millis- tm.tv_sec *1000)*1000000; 
    
    if(clock_settime(CLOCK_REALTIME, &tm) ==-1)
       perror("Clock set time");

    
}


JNIEXPORT jlong JNICALL Java_javax_realtime_RealtimeClock_getMilliseconds(JNIEnv *p_env,jclass pclass)
 {
    struct timespec start;
    jint temp;
    jlong millis,nanos;
    
            
   
    if(clock_gettime(CLOCK_REALTIME,&start) == -1)
      perror(" Error: clock get start ");
   
    
    millis=((jlong)(start.tv_sec)) *1000;
  
    nanos=start.tv_nsec;
    if(nanos>1000000)
    {
        temp=(jint)nanos/1000000;
        millis=millis + temp;
        nanos=nanos-temp *1000000;
    }
   
   
    return millis;
 }

JNIEXPORT jlong JNICALL Java_javax_realtime_RealtimeClock_getNanoseconds(JNIEnv *p_env,jclass pclass)
 {
    struct timespec start;
    jlong temp;
    jlong millis,nanos;
            
   
    if(clock_gettime(CLOCK_REALTIME,&start) == -1)
      perror(" Error: clock get start ");

    millis=((jlong)start.tv_sec) *1000;

    nanos=(jlong)start.tv_nsec;
    if(nanos>1000000)
    {   temp=(nanos/1000000);
        millis=millis + temp;
        nanos=nanos-temp *1000000;
    }
    return nanos;
 }
 
 JNIEXPORT jlong JNICALL Java_javax_realtime_RealtimeClock_nativeGetRes(JNIEnv *p_env,jclass pclass)
 {
   struct timespec res;

    if(clock_getres(CLOCK_REALTIME, &res) == -1)
    {
        perror("Error: clock get resolution");

    }
  
  return res.tv_nsec;
  
 }

 JNIEXPORT void JNICALL Java_javax_realtime_RealtimeClock_nativeGetTime(JNIEnv *p_env,jclass pclass,
                                                                 jlongArray ar )
 {
    struct timespec start;
    jlong temp;
    jlong millis,nanos;
    jlong tn[2];

         
   
    if(clock_gettime(CLOCK_REALTIME,&start) == -1)
      perror(" Error: clock get start ");

    millis=((jlong)start.tv_sec) *1000;

    nanos=(jlong)start.tv_nsec;
    if(nanos>1000000)
    {   temp=nanos/1000000;
        millis=millis + temp;
        nanos=nanos-temp *1000000;
    }

    tn[0]=millis;
    tn[1]=nanos;

    (*p_env)->SetLongArrayRegion(p_env,ar,0,2,tn);
    return;
 }

 JNIEXPORT void JNICALL Java_javax_realtime_RealtimeClock_nativeSetRes(JNIEnv *p_env, jclass pclass,
                                                                     jlong millis,jlong nanos)
 {
     struct _clockperiod nw;
     struct _clockperiod old;
     jint rt;
     nw.nsec=millis *1000000 + nanos;

     nw.fract=0;

     rt=ClockPeriod(CLOCK_REALTIME,&nw,&old,0);

 }
     




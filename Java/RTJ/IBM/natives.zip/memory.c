
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include "memarea.h"
#include "chkassign.h"

#define HASHPRIME 31

//#define DEBUG_FUNCTIONS

// #define DEBUG(x) printf x
#define DEBUG(x)

//#define DEBUG_VERBOSE(x) printf x
#define DEBUG_VERBOSE(x)

//#define ASSERT(x,y) if(!(x)) printf("<ASSERT FAILED: %s>\n", y)
#define ASSERT(x, string)

typedef struct AreaRangeTree {
    void * startAddress;
    void * endAddress;
    void * outerScopeAddress;
    struct AreaRangeTree * leftChild;
    struct AreaRangeTree * rightChild;
} MemoryAreaRangeTree, * MemoryAreaRangeTreePtr;

typedef struct AddressToTreeListNode {
    void * address;
    MemoryAreaRangeTreePtr tree;
    struct AddressToTreeListNode * next;
} AddressToTree, * AddressToTreePtr, ** AddressToTreeHashTable;

/* A binary tree with NULL pointers for external nodes and
 * MemoryAreaRangeTree for internal nodes. */
MemoryAreaRangeTreePtr memoryAreaRangeTreePtr = NULL;

/* An array representing a hash table */
AddressToTreeHashTable addressToTreeHashTable = NULL;

int numberOfEntries = 0;

int shouldCheck = TRUE;



JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_addToNativeSpaceTableImpl
  (JNIEnv * env, jobject jobj, jlong address, jlong size, jlong outerAddress) {
    addMemoryArea((void *)address, (void *)(address + size), (void *)outerAddress);
}

JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_removeFromNativeSpaceTableImpl
  (JNIEnv * env, jobject jobj, jlong address, jlong size, jlong outerAddress) {
    removeMemoryArea((void *)address, (void *)(address + size), (void *)outerAddress);
}

JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_startMemoryChecking
  (JNIEnv * env, jclass cls) {
    startChecking();
};

JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_stopMemoryChecking
  (JNIEnv * env, jclass cls) {
    stopChecking();
};

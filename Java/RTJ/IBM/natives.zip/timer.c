
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include <time.h>
#include <jni.h>
#include <stdio.h>  
#include <stdlib.h>

#include <sys/netmgr.h>
#include <sys/neutrino.h>
#include <sys/dispatch.h>
#include <pthread.h>


#define MY_PULSE_CODE _PULSE_CODE_MINAVAIL
  
typedef union
{
    struct _pulse pulse;
}back_message;

JNIEXPORT jint JNICALL Java_javax_realtime_Timer_getChannelID(JNIEnv *p_env, jclass pclass)
{
  jint chid;

  chid=ChannelCreate(0);
  
   
  return chid;
}

        
/**
 * just create timer,leave it unfired, it need timer_settime to fire the timer 
 */
 JNIEXPORT jint JNICALL Java_javax_realtime_Timer_createTimer(JNIEnv *p_env, jclass pclass,jint chid)
{                 
    struct sigevent event;
    timer_t timer_id;
    dispatch_t *dpp;
   
    event.sigev_notify = SIGEV_PULSE;
    event.sigev_coid=ConnectAttach(ND_LOCAL_NODE, 0, chid, _NTO_SIDE_CHANNEL,0);
    event.sigev_priority =getprio(0);
    event.sigev_code = MY_PULSE_CODE;

    timer_create(CLOCK_REALTIME,&event,&timer_id);


    return (jint)timer_id;
}



JNIEXPORT void Java_javax_realtime_Timer_rcvTimer(JNIEnv *penv, jobject pobj,
                                             jint chid,jboolean isEnabled)
{
    int rcvid;
    back_message msg;
    jmethodID mID;
    jclass cID;

    rcvid=MsgReceive(chid,&msg,sizeof(msg),NULL);
    if(rcvid==0)
    {
           if(msg.pulse.code == MY_PULSE_CODE && isEnabled)
           {
 
               cID=(*penv)->FindClass(penv,"javax/realtime/Timer");
               mID=(*penv)->GetMethodID(penv,cID,"fire","()V");
              
               (*penv)->CallVoidMethod(penv,pobj,mID);
           }
    }
  }

 

/**
 * set timer, for oneshot timer, interval is 0, so millis2=0 and nanos2=0
 */
JNIEXPORT void JNICALL Java_javax_realtime_Timer_setTimer(JNIEnv *p_env, jclass pclass, 
                              jint tmID, jlong millis1, jlong nanos1, jlong millis2, jlong nanos2)

{
    struct itimerspec itime;

    itime.it_value.tv_sec= millis1 /1000;
    itime.it_value.tv_nsec=(millis1 - (millis1/1000) *1000)*1000000 + nanos1;
    itime.it_interval.tv_sec=millis2/1000;
    itime.it_interval.tv_nsec=(millis2-(millis2/1000)*1000) * 1000000 + nanos2;

        
    timer_settime((timer_t)tmID,0, &itime, NULL);

}



 

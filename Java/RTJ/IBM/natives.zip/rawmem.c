
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include <stdlib.h>
#include <sys/mman.h>
#include <errno.h>
#include <jni.h>
#include "rawmem.h"

// #define DEBUG
// #define BDEBUG // show all byte read/writes (but not int, long, etc...)


JNIEXPORT jlong JNICALL Java_javax_realtime_RawMemoryAccess_nativeMap(JNIEnv *p_env,
                                                                      jobject p_object,
                                                                      jlong base,
                                                                      jlong size)
{
    void *ptr;
    void* pbase = (void*) base;
    
    p_env;
    p_object;

    errno = 0;

#ifdef DEBUG
    printf("<Mapping to physical address: %d with size: %d>\n", pbase, (uint64_t) size);
#endif

    /* The first param is NULL because we don't care where in our virtual memory space it gets mapped to.
       We don't want the memory cached because it might be device memory.
       I'm leaving the memory as private until I find out that I can't. :)
       The pbase is the physical location we want to map to.
    */
    ptr = mmap_device_memory (NULL, size, PROT_READ|PROT_WRITE|PROT_NOCACHE, MAP_PRIVATE, pbase);
    
#ifdef DEBUG
    printf("<Mapped to: %d>\n", ptr);
#endif

#ifdef DEBUG
    if (ptr==MAP_FAILED) {
        printf("Error in mapping: %d\n", errno);
        switch (errno) {
        case EOK:
            printf("  EOK - Error value not set.\n");
            break;
        case EACCES:
            printf("  EACCES - The file descriptor in fildes isn't open for read,\n  or PROT_WRITE and MAP_SHARED was specified and fildes wasn't\n  open for write. \n");
            break;
        case EBADF:
            printf("  EBADF - The fildes argument isn't a valid open file descriptor.\n");
            break;
        case EINVAL:
            printf("  EINVAL - The flags type is invalid.\n");
            break;
        case ENODEV:
            printf("  ENODEV - The fildes argument refers to an object for which mmap()\n  is meaningless (e.g. a terminal).\n");
            break;
        case ENOMEM:
            printf("  ENOMEM - MAP_FIXED was specified and the address range requested\n  is outside of the allowed process address range,\n  or there wasn't enough memory to satisfy the request.\n");
            break;
        case ENXIO:
            printf("  ENXIO - The address from off for len bytes is invalid for the requested\n  object, or if MAP_FIXED is specified and addr,\n  len, off are invalid for the requested object.\n");
            break;
        default:
            printf("  %d - Unknown error type\n", errno);
        }
        errno = EOK;
    }
#endif
    return (jlong)ptr; 
}
    
JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeUnmap(JNIEnv *p_env,
                                                                       jobject p_object,
                                                                       jlong mappedBase,
                                                                       jlong size)
{
    int munmapResult;

    p_env;
    p_object;

    munmapResult = munmap_device_memory((void *)mappedBase, size);

#ifdef DEBUG
    if (munmapResult == -1) {
        printf("munmap_device_memory failed\n");
        switch (errno) {
        case EOK:
            printf("  EOK - Error value not set.\n");
            break;
        case EINVAL:
            printf("  EINVAL - The addresses in the specified range are outside the\n  range allowed for the address space of a process.\n");
            break;
        case ENOSYS:
            printf("  ENOSYS - The function munmap() isn't supported by this implementation.\n");
            break;
        default:
            printf("  %d - Unknown error type\n", errno);
        }
        errno = EOK;
    } else
        printf("Unmapped OK\n"); 
#endif

}

JNIEXPORT jbyte JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetByte(JNIEnv *p_env,
                                                                          jobject p_object,
                                                                          jlong mappedBase,
                                                                          jlong offset)
{
    jbyte tmp=0;

    tmp = (volatile) *((jbyte *)(mappedBase + offset));
    return tmp;
}

JNIEXPORT jint JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetInt(JNIEnv *p_env,
                                                                        jobject p_object,
                                                                        jlong mappedBase,
                                                                        jlong offset)
{
    jint tmp=0;

    tmp = (volatile) *((jint *)(mappedBase + offset));
    return tmp;
}

JNIEXPORT jlong JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetLong(JNIEnv *p_env,
                                                                          jobject p_object,
                                                                          jlong mappedBase,
                                                                          jlong offset)
{
    jlong tmp=0;

    tmp = (volatile) *((jlong *)(mappedBase + offset));
    return tmp;
}

JNIEXPORT jshort JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetShort(JNIEnv *p_env,
                                                                            jobject p_object,
                                                                            jlong mappedBase,
                                                                            jlong offset)
{
    jshort tmp=0;

    tmp = (volatile) *((jshort *)(mappedBase + offset));
    return tmp;
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetByte(JNIEnv *p_env,
                                                                         jobject p_object,
                                                                         jlong mappedBase,
                                                                         jlong offset,
                                                                         jbyte value)
{
    p_env;
    p_object;

    *((jbyte *)(mappedBase + offset)) = value;
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetInt(JNIEnv *p_env,
                                                                        jobject p_object,
                                                                        jlong mappedBase,
                                                                        jlong offset,
                                                                        jint value)
{
    p_env;
    p_object;

    *((jint *)(mappedBase + offset)) = value;
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetLong(JNIEnv *p_env,
                                                                         jobject p_object,
                                                                         jlong mappedBase,
                                                                         jlong offset,
                                                                         jlong value)
{
    p_env;
    p_object;

    *((jlong *)(mappedBase + offset)) = value;
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetShort(JNIEnv *p_env,
                                                                          jobject p_object,
                                                                          jlong mappedBase,
                                                                          jlong offset,
                                                                          jshort value)
{
    p_env;
    p_object;

    *((jshort *)(mappedBase + offset)) = value;
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetBytes(JNIEnv *p_env,
                                                                          jobject p_object,
                                                                          jlong mappedBase,
                                                                          jlong offset,
                                                                          jbyteArray bytes,
                                                                          jint low,
                                                                          jint n)
{
    p_object;
    (*p_env)->SetByteArrayRegion(p_env, bytes, low, n, (jbyte *)(mappedBase + offset));
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetInts(JNIEnv *p_env,
                                                                         jobject p_object,
                                                                         jlong mappedBase,
                                                                         jlong offset,
                                                                         jintArray ints,
                                                                         jint low,
                                                                         jint n)
{
    p_object;
    (*p_env)->SetIntArrayRegion(p_env, ints, low, n, (jint *)(mappedBase + offset));
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetLongs(JNIEnv *p_env,
                                                                          jobject p_object,
                                                                          jlong mappedBase,
                                                                          jlong offset,
                                                                          jlongArray longs,
                                                                          jint low,
                                                                          jint n)
{
    p_object;
    (*p_env)->SetLongArrayRegion(p_env, longs, low, n, (jlong *)(mappedBase + offset));
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeGetShorts(JNIEnv *p_env,
                                                                           jobject p_object,
                                                                           jlong mappedBase,
                                                                           jlong offset,
                                                                           jshortArray shorts,
                                                                           jint low,
                                                                           jint n)
{
    p_object;
    (*p_env)->SetShortArrayRegion(p_env, shorts, low, n, (jshort *)(mappedBase + offset));
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetBytes(JNIEnv *p_env,
                                                                          jobject p_object,
                                                                          jlong mappedBase,
                                                                          jlong offset,
                                                                          jbyteArray bytes,
                                                                          jint low,
                                                                          jint n)
{
    jbyte *bytesPtr;
    p_object;

    bytesPtr = (*p_env)->GetByteArrayElements(p_env, bytes, NULL);
    memcpy ((jbyte *)(mappedBase + offset), bytesPtr + low, n * sizeof(jbyte));
    (*p_env)->ReleaseByteArrayElements(p_env, bytes, bytesPtr, JNI_ABORT);
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetInts(JNIEnv *p_env,
                                                                         jobject p_object,
                                                                         jlong mappedBase,
                                                                         jlong offset,
                                                                         jintArray ints,
                                                                         jint low,
                                                                         jint n)
{
    jint *intsPtr;
    p_object;

    intsPtr = (*p_env)->GetIntArrayElements(p_env, ints, NULL);
    memcpy ((jint *)(mappedBase + offset), intsPtr + low, n * sizeof(jint));
    
    (*p_env)->ReleaseByteArrayElements(p_env, ints, intsPtr, JNI_ABORT);
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetLongs(JNIEnv *p_env,
                                                                          jobject p_object,
                                                                          jlong mappedBase,
                                                                          jlong offset,
                                                                          jlongArray longs,
                                                                          jint low,
                                                                          jint n)
{
    jlong *longsPtr;
    p_object;

    longsPtr = (*p_env)->GetByteArrayElements(p_env, longs, NULL);
    memcpy ((jlong *)(mappedBase + offset), longsPtr + low, n * sizeof(jlong));
    (*p_env)->ReleaseByteArrayElements(p_env, longs, longsPtr, JNI_ABORT);
}

JNIEXPORT void JNICALL Java_javax_realtime_RawMemoryAccess_nativeSetShorts(JNIEnv *p_env,
                                                                           jobject p_object,
                                                                           jlong mappedBase,
                                                                           jlong offset,
                                                                           jshortArray shorts,
                                                                           jint low,
                                                                           jint n)
{
    jshort *shortsPtr;
    p_object;

    shortsPtr = (*p_env)->GetByteArrayElements(p_env, shorts, NULL);
    memcpy ((jshort *)(mappedBase + offset), shortsPtr + low, n * sizeof(jshort));
    (*p_env)->ReleaseByteArrayElements(p_env, shorts, shortsPtr, JNI_ABORT);
}
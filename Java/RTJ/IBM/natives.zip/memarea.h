
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include <jni.h>
/* Header for class javax_realtime_MemoryArea */

#ifndef _MEMAREA
#define _MEMAREA
#ifdef __cplusplus
extern "C" {
#endif
#undef javax_realtime_MemoryArea_NOT_USED
#define javax_realtime_MemoryArea_NOT_USED -1LL
/* Inaccessible static: memorySpaceToMemoryAreaTable */
/*
 * Class:     javax_realtime_MemoryArea
 * Method:    addToNativeSpaceTableImpl
 * Signature: (JJJ)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_addToNativeSpaceTableImpl
  (JNIEnv *, jclass, jlong, jlong, jlong);
/*
 * Class:     javax_realtime_MemoryArea
 * Method:    removeFromNativeSpaceTableImpl
 * Signature: (JJJ)V
 */
JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_removeFromNativeSpaceTableImpl
  (JNIEnv *, jclass, jlong, jlong, jlong);


/*
 * Class:     javax_realtime_MemoryArea
 * Method:    startMemoryChecking
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_startMemoryChecking
  (JNIEnv *, jclass);

/*
 * Class:     javax_realtime_MemoryArea
 * Method:    stopMemoryChecking
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_javax_realtime_MemoryArea_stopMemoryChecking
  (JNIEnv *, jclass);

#ifdef __cplusplus
}
#endif
#endif

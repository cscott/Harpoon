
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include <time.h>
#include <jni.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/neutrino.h>

JNIEXPORT jlong JNICALL Java_javax_realtime_Clock_nativeGetRes(JNIEnv *p_env,
                                                               jclass pclass)
{
    struct timespec res;

    if(clock_getres(CLOCK_REALTIME, &res) == -1)
    {
        perror("Error: clock get resolution");

    }
    return res.tv_nsec;
 
}

JNIEXPORT void JNICALL Java_javax_realtime_Clock_nativeGetTime(JNIEnv *p_env,
                                                               jclass pclass, 
                                                               jlongArray ar )
{
    struct timespec start;
    jint temp;
    jlong millis,nanos;
    jlong tn[2];

    if(clock_gettime(CLOCK_REALTIME,&start) == -1)
        perror(" Error: clock get start ");

    millis=start.tv_sec *1000;

    nanos=start.tv_nsec;
    if(nanos>1000000)
    {   
        temp=nanos/1000000;
        millis=millis + temp;
        nanos=nanos-temp *1000000;
    }

    tn[0]=millis;
    tn[1]=nanos;

    (*p_env)->SetLongArrayRegion(p_env,ar,0,2,tn);
    return;
}

JNIEXPORT void JNICALL Java_javax_realtime_Clock_nativeSetRes(JNIEnv *p_env, 
                                                              jclass pclass,
                                                              jlong millis,
                                                              jint nanos)
{
    struct _clockperiod nw;
    struct _clockperiod old;
    jint rt;
    nw.nsec=millis *1000000 + nanos;

    nw.fract=0;

    rt=ClockPeriod(CLOCK_REALTIME,&nw,&old,0);

}
    


JNIEXPORT void JNICALL Java_javax_realtime_RealtimeThread_absSleep(JNIEnv *p_env, 
                                                                   jclass pclass,
                                                                   jlong millis,
                                                                   jlong nanos)
{
    struct timespec res;

    time_t  tv_sec;
    long    tv_nsec;

    if (millis < 1000)
    {
        res.tv_sec = 0;
        res.tv_nsec = nanos + (millis*1000);

    } else 
    {
        res.tv_sec = millis/1000;
        res.tv_nsec = nanos;
    }

    if (nanosleep_abs(CLOCK_REALTIME, &res) < 0)
    {
        /* Find and throw InterruptedException */
        jclass newExcCls = (*p_env)->FindClass(p_env, "java/lang/InterruptedException");
        if (newExcCls == 0) { /* Unable to find the new exception class, give up. */
            return;
        }
        (*p_env)->ThrowNew(p_env, newExcCls, "Failed to sleep");
        return;

    } else return;


}


JNIEXPORT void JNICALL Java_javax_realtime_RealtimeThread_relSleep(JNIEnv *p_env, 
                                                                   jclass pclass,
                                                                   jlong millis,
                                                                   jlong nanos)
{
    struct timespec res;

    time_t  tv_sec;
    long    tv_nsec;

    if (millis < 1000)
    {
        res.tv_sec = 0;
        res.tv_nsec = nanos + (millis*1000);

    } else 
    {
        res.tv_sec = millis/1000;
        res.tv_nsec = nanos;
    }

    if (nanosleep(&res, 0) < 0)
    {
        /* Find and throw InterruptedException */
        jclass newExcCls = (*p_env)->FindClass(p_env, "java/lang/InterruptedException");
        if (newExcCls == 0) { /* Unable to find the new exception class, give up. */
            return;
        }
        (*p_env)->ThrowNew(p_env, newExcCls, "Failed to sleep");
        return;

    } else return;
}


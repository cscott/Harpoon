
/*
 * Licensed Materials - Property of IBM,
 * (c) Copyright IBM Corp. 1999, 2000  All Rights Reserved
 */


#include <signal.h>
#include <stdio.h>
#include "jni.h"

static JNIEnv* penv_=0;
static int jniSet_=0;

void callJavaPosixSigHappens(int signal);


JNIEXPORT void JNICALL Java_javax_realtime_POSIXSignalHandler_nativeAddHandler(JNIEnv *penv,
                                                                               jobject pobj,
                                                                               jint sig)
{
    if (jniSet_==0)
    {
        penv_=penv;
        jniSet_=1;
    }

    signal(sig, callJavaPosixSigHappens);
}


void callJavaPosixSigHappens(int signal)
{
    jmethodID mID;
    jclass cID;

    if (signal==SIGABRT)
    {
        cID=(*penv_)->FindClass(penv_,"javax/realtime/POSIXSignalHandler");
        mID=(*penv_)->GetStaticMethodID(penv_,cID,"signalCallback","(I)V");
        if (mID)
            (*penv_)->CallStaticVoidMethod(penv_,cID,mID,signal);
    }
}

